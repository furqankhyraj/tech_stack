//index.andriod.js - Place code in here for android

// Import library for making Component
import React from 'react';
import { Text, View } from 'react-native';

// Make Component
const Header = (props) => {
  const { textStyle, viewStyle } = styles;
    return (
    <View style={viewStyle}>
    <Text style={textStyle}>{props.headerText}</Text>
    </View>
  );
  };

  const styles = {
    viewStyle: {
        backgroundColor: '#1c398c',
        justifyContent: 'center',
        alignItems: 'center',
        height: 60,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 20 },
        shadowOpacity: 0.5,

    },
    textStyle: {
      fontSize: 20,
      color: '#F8f8f8'
    }

  };
//Make the Component available to other parts of the app
export { Header };
